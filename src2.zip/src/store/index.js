import {configureStore} from "@reduxjs/toolkit"
import createUserSliceReducer from "./createUser"

const store = configureStore({
    reduser: {
        createUser: createUserSliceReducer
    }
})
export default store;